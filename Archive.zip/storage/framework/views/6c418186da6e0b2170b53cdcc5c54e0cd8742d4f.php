<?php $__env->startComponent('mail::message'); ?>
# Contact from submitted

Someone submitted contact from to your site

From Information:

Name: <?php echo e($data['msg_name']); ?><br/>
Email: <?php echo e($data['email']); ?><br/>
Title: <?php echo e($data['msg_title']); ?><br/>
Message: <?php echo e($data['message']); ?><br/>

Thanks,<br>
<?php echo e(config('app.name')); ?>

<?php echo $__env->renderComponent(); ?>
