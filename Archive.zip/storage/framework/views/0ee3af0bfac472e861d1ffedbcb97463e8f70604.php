<?php $__env->startSection("contentheader_title", "Blog"); ?>
<?php $__env->startSection("contentheader_description", "Blog"); ?>

<?php $__env->startSection("main-content"); ?>

    <div class="breadcrumb">
        <div class="container">
            <div class="breadcrumb-inner">
                <ul class="list-inline list-unstyled">
                    <li><a href="/">Home</a></li>
                    <li class='active'>Blog</li>
                </ul>
            </div>
            <!-- /.breadcrumb-inner -->
        </div>
        <!-- /.container -->
    </div>

    <div class="body-content">
        <div class="container">
            <div class="row">
                <div class="blog-page">
                    <div class="col-xs-12 col-sm-9 col-md-9 rht-col">
                    <?php $__currentLoopData = $blogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="blog-post  wow fadeInUp">
                            <a href="<?php echo e(URL::to('/')); ?>/blog/<?php echo e($blog->slug); ?>"><img class="img-responsive" src="<?php echo e(URL::to('/')); ?>/public/storage/<?php echo e($blog->image); ?>" alt="<?php echo e($blog->title); ?>"></a>
                            <h1><a href="<?php echo e(URL::to('/')); ?>/blog/<?php echo e($blog->slug); ?>"><?php echo e($blog->title); ?></a></h1>
                            <!-- <span class="author">farhad</span>
                            <span class="review">6 Comments</span> -->
                            <span class="date-time"><?php echo e($blog->created_at); ?></span>
                            <p><?php echo $blog->excerpt; ?></p>
                            <a href="<?php echo e(URL::to('/')); ?>/blog/<?php echo e($blog->slug); ?>" class="btn btn-upper btn-primary read-more">read more</a>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        <div class="clearfix blog-pagination filters-container  wow fadeInUp" style="padding:0px; background:none; box-shadow:none; margin-top:15px; border:none">

                            <div class="text-right">
                                <div class="pagination-container">
                                <?php echo e($blogs->links()); ?>

                                    <!-- /.list-inline -->
                                </div>
                                <!-- /.pagination-container -->
                            </div>
                            <!-- /.text-right -->

                        </div>
                        <!-- /.filters-container -->
                    </div>
                    <div class="col-xs-12 col-sm-3 col-md-3 sidebar">

                        <div class="sidebar-module-container">


                            <?php echo $__env->make('common.blogside', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

                            <!-- /.sidebar-widget -->
                            <!-- ============================================== PRODUCT TAGS : END ============================================== -->
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make("layout.app", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>