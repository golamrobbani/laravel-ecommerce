<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Order Invoice <?php echo e($order->order_number); ?></title>

    <style type="text/css">
        * {
            font-family: Verdana, Arial, sans-serif;
        }
        table{
            font-size: x-small;
        }
        tfoot tr td{
            font-weight: bold;
            font-size: x-small;
        }
        .gray {
            background-color: lightgray
        }
    </style>

</head>
<body>

<table width="100%">
    <tr>
        <td valign="top"><img src="assets/images/logo.png" alt="" width="150"/></td>
        <td align="right">
            <h3><?php echo e($order->shop['shop_title']); ?></h3>
            <pre>
                <?php echo e($order->shop['shop_address']); ?>

                <?php echo e($order->shop['shop_phone']); ?>

                <?php echo e($order->shop['shop_email']); ?>

            </pre>
            <h4>Order Number: #<?php echo e($order->order_number); ?></h4>
            <h5>Delivery Address: <?php echo e($order->order_delivery_address); ?>, <?php echo e($order->order_delivery_phone); ?></h5>
        </td>
    </tr>

</table>

<table width="100%">
    <tr>
        <td><strong>From:</strong> <?php echo e($order->shop['shop_title']); ?></td>
        <td><strong>To:</strong> <?php echo e($order->user['name']); ?></td>
    </tr>

</table>

<br/>

<table width="100%">
    <thead style="background-color: lightgray;">
    <tr>
        <th>#</th>
        <th>Product</th>
        <th>Quantity</th>
        <th>Unit Price (Tk)</th>
        <th>Total (Tk)</th>
    </tr>
    </thead>
    <tbody>
    <?php $__currentLoopData = $order->products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <th scope="row">1</th>
            <td><?php echo e($product['name']); ?></td>
            <td align="right"><?php echo e($product['qty']); ?></td>
            <td align="right"><?php echo e($product['price']); ?></td>
            <td align="right"><?php echo e($product['price'] * $product['qty']); ?></td>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>

    <tfoot>
    <tr>
        <td colspan="3"></td>
        <td align="right">Subtotal (Tk)</td>
        <td align="right"><?php echo e($order->order_price_total); ?></td>
    </tr>
    <tr>
        <td colspan="3"></td>
        <td align="right">Delivery Charge (Tk)</td>
        <td align="right"><?php echo e($order->order_delivery_charge); ?></td>
    </tr>
    <tr>
        <td colspan="3"></td>
        <td align="right">Discount (Tk)</td>
        <td align="right"><?php echo e($order->order_discount); ?></td>
    </tr>
    <tr>
        <td colspan="3"></td>
        <td align="right">Total (Tk)</td>
        <td align="right" class="gray"><?php echo e($order->order_total_payable); ?></td>
    </tr>
    </tfoot>
</table>

</body>
</html>