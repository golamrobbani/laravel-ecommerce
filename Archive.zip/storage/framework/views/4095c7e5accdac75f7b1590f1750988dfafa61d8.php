    <!-- ============================================== HEADER ============================================== -->
    <header class="header-style-1">

        <!-- ============================================== TOP MENU ============================================== -->
        <div class="top-bar animate-dropdown">
            <div class="container">
                <div class="header-top-inner">
                    <div class="cnt-account">
                        <ul class="list-unstyled">
                            <!-- <li class="wishlist"><a href="<?php echo e(URL::to('/')); ?>/wishlist"><span>Wishlist ({{ wishlist.length }})</span></a></li>
                            <li class="header_cart hidden-xs"><a href="<?php echo e(URL::to('/')); ?>/cart"><span>My Cart  ({{ cart.length }})</span></a></li> -->

                            <?php if(Auth::guest()): ?>
                                <li class="login"><a href="<?php echo e(URL::to('/')); ?>/login"><span>Login / Register</span></a></li>
                            <?php else: ?>
                                <li class="myaccount"><a href="<?php echo e(URL::to('/')); ?>/myaccount"><span>My Account <b>(<?php echo e(Auth::user()->name); ?>)</b></span></a></li>
                            <?php endif; ?>

                        </ul>
                    </div>
                    <!-- /.cnt-account -->
					<div class="cnt-block">
						<div class="logo">
                            <a href="/"> <img src="<?php echo e(URL::to('/')); ?>/storage/<?php echo e($shop->shop_logo); ?>" alt="logo"> </a>
                        </div>
					</div>

                    <!-- /.cnt-cart -->
                    <div class="clearfix"></div>
                </div>
                <!-- /.header-top-inner -->
            </div>
            <!-- /.container -->
        </div>
        <!-- /.header-top -->


        <!-- ============================================== NAVBAR ============================================== -->
        <div class="header-nav animate-dropdown">
            <div class="container">
                <div class="yamm navbar navbar-default" role="navigation">
                    <div class="navbar-header">
                        <button data-target="#mc-horizontal-menu-collapse" data-toggle="collapse" class="navbar-toggle collapsed" type="button">
                            <span class="sr-only">Toggle navigation</span> <span class="icon-bar"></span> <span class="icon-bar"></span> <span class="icon-bar"></span> </button>
                    </div>
                    <div class="nav-bg-class">
                        <div class="navbar-collapse collapse" id="mc-horizontal-menu-collapse">
                            <div class="nav-outer">
                                <ul class="nav navbar-nav">
                                    <li class="active dropdown"> <a href="/">Home</a> </li>

                                    <?php $__currentLoopData = $menus['main_menus']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li class="dropdown yamm mega-menu"> <a href="<?php echo e(URL::to('/')); ?>/category/<?php echo e($menu->slug); ?>" data-hover="dropdown" class="dropdown-toggle" ><?php echo e($menu->name); ?> <?php if($menu->menu_tag): ?> <span class="menu-label hot-menu hidden-xs"><?php echo e($menu->menu_tag); ?></span> <?php endif; ?></a>
                                       <?php if($menu->submenus->first()): ?>
                                            <?php
                                                $name = 'category';
                                                if($menu->display_item == 'yes'){
                                                    $name = 'product';
                                                }
                                            ?>
                                        <ul class="dropdown-menu container">
                                            <li>
                                                <div class="yamm-content ">
                                                    <div class="row">
                                                        <div class="col-xs-12 col-sm-6 col-md-2 col-menu">
                                                            <h2 class="title"><?php echo e($menu->submenu_heading); ?></h2>
                                                            <ul class="links">
                                                                <?php $__currentLoopData = $menu['submenus']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $single): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                     <li><a href="<?php echo e(URL::to('/')); ?>/<?php echo e($name); ?>/<?php echo e($single->slug); ?>"><?php echo e($single->name); ?></a></li>
                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                                            </ul>
                                                        </div>


                                                        <!-- /.col -->


                                                        <div class="col-xs-12 col-sm-6 col-md-4 col-menu banner-image">
															<img class="img-responsive" src="<?php echo e(URL::to('/')); ?>/storage/<?php echo e($menu->category_image); ?>" alt="<?php echo e($menu->name); ?>">
														</div>
                                                        <!-- /.yamm-content -->
                                                    </div>
                                                </div>
                                            </li>
                                        </ul>
                                        <?php endif; ?>
                                    </li>

                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                     <li class="dropdown"> <a href="<?php echo e(URL::to('/')); ?>/contact">Contact Us</a> </li>
                                    <li class="dropdown"> <a href="<?php echo e(URL::to('/')); ?>/blog">Blog</a> </li>
                                    <li class="pull-right">
                                        <form action="/search" method="get">
                                            <div class="control-group">
                                                 <input class="search-box" placeholder="Search here..." name="q"/>
                                                <a class="search-button" href="#"></a>
                                            </div>
                                        </form>
                                    </li>

                                </ul>
                                <!-- /.navbar-nav -->
                                <div class="clearfix"></div>
                            </div>
                            <!-- /.nav-outer -->
                        </div>
                        <!-- /.navbar-collapse -->
                    </div>
                    <!-- /.nav-bg-class -->
                </div>
                <!-- /.navbar-default -->
                        <!-- /.search-area -->
            </div>
            <!-- /.container-class -->
        </div>
        <!-- /.header-nav -->
        <!-- ============================================== NAVBAR : END ============================================== -->
    </header>
    <!-- ============================================== HEADER : END ============================================== -->
