
   <div class="search-area outer-bottom-small">
                                <form>
                                    <div class="control-group">
                                        <input placeholder="Type to search" class="search-field">
                                        <a href="#" class="search-button"></a>
                                    </div>
                                </form>
                            </div>

                            <div class="home-banner outer-top-n outer-bottom-xs">
                                <?php $__currentLoopData = $banners; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $banner): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="home-banner outer-top-n outer-bottom-xs">
                                    <a href="<?php echo e($banner->link); ?>"> <img style="width: 100%;" src="<?php echo e(URL::to('/')); ?>/public/storage/<?php echo e($banner->image); ?>" alt="Image"> </a>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                            <!-- ==============================================CATEGORY============================================== -->
                            <div class="sidebar-widget outer-bottom-xs wow fadeInUp">
                                <h3 class="section-title">Category</h3>
                                <div class="sidebar-widget-body m-t-10">
                                    <div class="accordion">


                                    <?php $__currentLoopData = $menus['main_menus']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="accordion-group">
                                            <div class="accordion-heading">
                                                <a href="#<?php echo e($menu->id); ?>" data-toggle="collapse" class="accordion-toggle collapsed"> <?php echo e($menu->name); ?> </a>
                                            </div>
                                            <!-- /.accordion-heading -->
                                            <div class="accordion-body collapse" id="<?php echo e($menu->id); ?>" style="height: 0px;">
                                                <div class="accordion-inner">
                                                    <ul>
                                                        <?php $__currentLoopData = $menu['submenus']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $single): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <li><a href="<?php echo e(URL::to('/')); ?>/category/<?php echo e($single->slug); ?>"><?php echo e($single->name); ?></a></li>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </ul>
                                                </div>
                                                <!-- /.accordion-inner -->
                                            </div>
                                            <!-- /.accordion-body -->
                                        </div>
                                        <!-- /.accordion-group -->

                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



                                    </div>
                                    <!-- /.accordion -->
                                </div>
                                <!-- /.sidebar-widget-body -->
                            </div>
                            <!-- /.sidebar-widget -->



 <!-- ============================================== CATEGORY : END ============================================== -->
 <div class="sidebar-widget outer-bottom-xs wow fadeInUp">
                                <h3 class="section-title">Tab Widget</h3>

<ul class="nav nav-tabs">
                                    <li class="active"><a href="#popular" data-toggle="tab">popular post</a></li>
                                    <li><a href="#recent" data-toggle="tab">Recent post</a></li>
                                </ul>
                                <div class="tab-content" style="padding-left:0">
                                    <div class="tab-pane active m-t-20" id="popular">

                                    <?php $__currentLoopData = $populars; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="blog-post  nner-bottom-30 ">
                                            <a href="<?php echo e(URL::to('/')); ?>/blog/<?php echo e($blog->slug); ?>"><img class="img-responsive" src="<?php echo e(URL::to('/')); ?>/public/storage/<?php echo e($blog->image); ?>" alt="<?php echo e($blog->title); ?>"></a>
                                            <h1><a href="<?php echo e(URL::to('/')); ?>/blog/<?php echo e($blog->slug); ?>"><?php echo e($blog->title); ?></a></h1>
                                            <!-- <span class="author">farhad</span>
                                            <span class="review">6 Comments</span> -->
                                            <span class="date-time"><?php echo e($blog->created_at); ?></span>
                                            <p><?php echo $blog->excerpt; ?></p>
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                                    </div>

                                    <div class="tab-pane m-t-20" id="recent">
                                        <?php $__currentLoopData = $latests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <div class="blog-post  nner-bottom-30 ">
                                                <a href="<?php echo e(URL::to('/')); ?>/blog/<?php echo e($blog->slug); ?>"><img class="img-responsive" src="<?php echo e(URL::to('/')); ?>/public/storage/<?php echo e($blog->image); ?>" alt="<?php echo e($blog->title); ?>"></a>
                                                <h1><a href="<?php echo e(URL::to('/')); ?>/blog/<?php echo e($blog->slug); ?>"><?php echo e($blog->title); ?></a></h1>
                                                <!-- <span class="author">farhad</span>
                                                <span class="review">6 Comments</span> -->
                                                <span class="date-time"><?php echo e($blog->created_at); ?></span>
                                                <p><?php echo $blog->excerpt; ?></p>
                                            </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                </div>


                            </div>
