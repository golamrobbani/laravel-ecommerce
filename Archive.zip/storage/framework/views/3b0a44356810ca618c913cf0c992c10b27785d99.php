<?php $__env->startSection("contentheader_title", $blog->title); ?>
<?php $__env->startSection("contentheader_description", $blog->body); ?>

<?php $__env->startSection("main-content"); ?>

    <div class="breadcrumb">
        <div class="container">
            <div class="breadcrumb-inner">
                <ul class="list-inline list-unstyled">
                    <li><a href="/">Home</a></li>
                    <li class='active'>Blog Details</li>
                </ul>
            </div>
            <!-- /.breadcrumb-inner -->
        </div>
        <!-- /.container -->
    </div>

    <div class="body-content">
        <div class="container">
            <div class="row">
                <div class="blog-page">
                    <div class="col-xs-12 col-sm-9 col-md-9 rht-col">

                        <div class="blog-post  wow fadeInUp">
                            <a href="<?php echo e(URL::to('/')); ?>/blog/<?php echo e($blog->slug); ?>"><img class="img-responsive" src="<?php echo e(URL::to('/')); ?>/public/storage/<?php echo e($blog->image); ?>" alt="<?php echo e($blog->title); ?>"></a>
                            <h1><a href="<?php echo e(URL::to('/')); ?>/blog/<?php echo e($blog->slug); ?>"><?php echo e($blog->title); ?></a></h1>
                            <!-- <span class="author">farhad</span>
                            <span class="review">6 Comments</span> -->
                            <span class="date-time"><?php echo e($blog->created_at); ?></span>
                            <p><?php echo $blog->body; ?></p>
                        </div>


                        <!-- /.filters-container -->
                    </div>
                    <div class="col-xs-12 col-sm-3 col-md-3 sidebar">

                        <div class="sidebar-module-container">

                            <?php echo $__env->make('common.blogside', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

                            <!-- /.sidebar-widget -->
                            <!-- ============================================== PRODUCT TAGS : END ============================================== -->
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make("layout.app", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>