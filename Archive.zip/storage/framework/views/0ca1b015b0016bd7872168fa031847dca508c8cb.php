<?php $__env->startComponent('mail::message'); ?>
# Order Conformation

Your order submitted successfully. Thank you for submitting order to us. We are start processing your order. We will inform you farther information about your order.

<?php $__env->startComponent('mail::button', ['url' => config('app.url').'/myaccount/order/'.$order->id]); ?>
View Order Details
<?php echo $__env->renderComponent(); ?>

Thanks,<br>
<?php echo e(config('app.name')); ?><br/>
<?php echo $__env->renderComponent(); ?>
