<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use App\Page;

class Page extends Model
{
   
    
}
