module.exports = {

    APP_NAME: "eCommerce Shop",
    APP_VERSION: 1,

    BASE_URL : 'http://127.0.0.1:8000',


}
