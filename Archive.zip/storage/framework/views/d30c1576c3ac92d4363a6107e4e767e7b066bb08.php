  <!-- ================================== TOP NAVIGATION ================================== -->
  <div class="side-menu animate-dropdown outer-bottom-xs">
                        <div class="head"><i class="icon fa fa-align-justify fa-fw"></i> Categories</div>
                        <nav class="yamm megamenu-horizontal">
                            <ul class="nav">

                            <?php $__currentLoopData = $menus['side_menus']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li class="dropdown menu-item" > <a href="<?php echo e(URL::to('/')); ?>/category/<?php echo e($menu->slug); ?>"  data-toggle="dropdown" class="dropdown-toggle" ><i class="icon fa fa-<?php echo e($menu->icon_name); ?>" aria-hidden="true"></i><?php echo e($menu->name); ?></a>
                                <?php if(count($menu->submenus) > 0): ?>
                                    <?php
                                        $name = 'category';
                                        if($menu->display_item == 'yes'){
                                            $name = 'product';
                                        }
                                    ?>
                                    <ul class="dropdown-menu mega-menu">
                                        <li class="yamm-content">
                                            <div class="row">
                                                <div class="col-sm-12 col-md-8">
                                                    <ul class="links list-unstyled">

                                                       <?php $__currentLoopData = $menu['submenus']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $single): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                     <li><a href="<?php echo e(URL::to('/')); ?>/<?php echo e($name); ?>/<?php echo e($single->slug); ?>"><?php echo e($single->name); ?></a></li>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </ul>
                                                </div>


                                                <!-- /.col -->
                                                <div class="col-sm-12 col-md-4">
                                                    <div class="hot_product">
														<a href="#"><img alt="<?php echo e($single->name); ?>" src="<?php echo e(URL::to('/')); ?>/public/storage/<?php echo e($menu->category_image); ?>"  /></a>
													</div>
                                                </div>
                                                <!-- /.col -->
                                            </div>
                                            <!-- /.row -->
                                        </li>
                                        <!-- /.yamm-content -->
                                    </ul>
                                    <?php endif; ?>
                                    <!-- /.dropdown-menu -->
                                </li>
                                <!-- /.menu-item -->
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </ul>
                            <!-- /.nav -->
                        </nav>
                        <!-- /.megamenu-horizontal -->
                    </div>
                    <!-- /.side-menu -->
                    <!-- ================================== TOP NAVIGATION : END ================================== -->
